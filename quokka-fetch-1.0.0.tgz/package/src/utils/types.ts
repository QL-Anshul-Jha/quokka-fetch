import { HttpMethod, ResponseType } from './enums';

export type JSONPrimitive = string | number | boolean | null;
export type JSONObject = { [key: string]: JSONValue };
export type JSONArray = JSONValue[];
export type JSONValue = JSONPrimitive | JSONObject | JSONArray;

export type QueryParams = Record<string, string | number | boolean | null | undefined>;

export type RequestPayload = JSONValue | BodyInit | null;

export type FetchOptions = Omit<RequestInit, 'method' | 'body'> & {
  method?: HttpMethod;
  query?: QueryParams;
  body?: RequestPayload;
  timeout?: number;
  responseType?: ResponseType;
};

export interface QuokkaRequestConfig extends FetchOptions {
  url: string;
}

export type InterceptedResponseData = JSONValue | Blob | ArrayBuffer | FormData | string;

export interface QuokkaInterceptors {
  request: Array<(config: QuokkaRequestConfig) => QuokkaRequestConfig | Promise<QuokkaRequestConfig>>;
  response: Array<(data: InterceptedResponseData, response: Response) => InterceptedResponseData | Promise<InterceptedResponseData>>;
  error: Array<(error: Error) => Promise<void> | void>;
}

export type QuokkaFetchConfig = {
  baseURL?: string;
  headers?: HeadersInit;
  responseType?: ResponseType;
};

export interface QuokkaRequestPayload extends Omit<FetchOptions, 'method' | 'body'> {
  url: string;
  method: HttpMethod | string;
  payload?: RequestPayload;
  params?: QueryParams;
}

export interface QuokkaCallable {
  <T = JSONValue>(payload: QuokkaRequestPayload): Promise<T>;
  
  // Fluent Event Hooks
  onRequest(handler: (config: QuokkaRequestConfig) => QuokkaRequestConfig | Promise<QuokkaRequestConfig>): this;
  onResponse(handler: (data: InterceptedResponseData, response: Response) => InterceptedResponseData | Promise<InterceptedResponseData>): this;
  onError(handler: (error: Error) => Promise<void> | void): this;
}
