import { InterceptedResponseData, QueryParams, RequestPayload } from './types';
import { ResponseType } from './enums';
import { parsers, errorFormats } from './conditions';

// Building query params 
export const buildQueryString = (query?: QueryParams): string => {
  const qs = query 
    ? new URLSearchParams(
        Object.entries(query)
          .filter(([_, val]) => val != null)
          .map(([k, v]) => [k, String(v)])
      ).toString()
    : '';
  return qs;
};

export const mergeHeaders = (defaultHeaders: HeadersInit, customHeaders?: HeadersInit): Headers => {
  const headers = new Headers(defaultHeaders);
  new Headers(customHeaders || {}).forEach((value, key) => headers.set(key, value));
  return headers;
};

export const parseResponseBody = async (response: Response, expectedType: ResponseType): Promise<InterceptedResponseData> => {
  return await (parsers[expectedType] || parsers[ResponseType.JSON])(response);
};

export const handleResponseError = (response: Response, expectedType: ResponseType, data: InterceptedResponseData): void => {
  const errorType = (typeof data === 'string') ? 'string' 
                  : (expectedType === ResponseType.JSON || expectedType === undefined) ? 'json' 
                  : 'other';

  // eslint-disable-next-line @typescript-eslint/no-unused-expressions
  !response.ok && (() => { throw new Error(`[QF Error] ${response.status} ${response.statusText}: ${errorFormats[errorType](data)}`); })();
};

//---------------------------------------------------------------------------------------------------------------------------------------//
//----------------------------------------------------MAJOR FUNCTIONS--------------------------------------------------------------------//
//---------------------------------------------------------------------------------------------------------------------------------------//

// Payload & Content-Type Resolution
import { getBodyStrategies, getSignalStrategies } from './conditions';

export const resolvePayloadAndHeaders = (rawBody: RequestPayload | undefined | null, headers: Headers): BodyInit | null | undefined => {
    const bodyStrategies = getBodyStrategies(headers);
    return (rawBody !== undefined && rawBody !== null)
      ? (bodyStrategies.find(s => s.match(rawBody)) || bodyStrategies[2]).action(rawBody)
      : undefined;
};

// Controller Management
export const createAbortController = (timeout?: number) => {
    const controller = timeout ? new AbortController() : undefined;
    const timeoutId = timeout ? setTimeout(() => controller?.abort(), timeout) : undefined;
    return { controller, timeoutSignal: controller?.signal, timeoutId };
};

// Signal Resolution Mapping
export const resolveFinalSignal = (timeout: number | undefined, customSignal: AbortSignal | null | undefined, controller: AbortController | undefined, timeoutSignal: AbortSignal | undefined) => {
    const type = `${!!timeout}_${!!customSignal}`;
    return getSignalStrategies(customSignal, controller, timeoutSignal)[type]();
};
