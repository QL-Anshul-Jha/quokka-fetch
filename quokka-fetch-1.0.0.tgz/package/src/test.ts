/* eslint-disable no-console */
import qf, { ResponseType, HttpMethod, QuokkaRequestConfig } from './index';

async function test() {
  try {
    console.log('Fetching from https://jsonplaceholder.typicode.com/users/1...');
    
    // Testing GET via Callable object
    const user = await qf<{name: string}>({
      url: 'https://jsonplaceholder.typicode.com/users/1',
      method: HttpMethod.GET
    });
    console.log('✅ GET Success:', user.name);

    // Testing POST via Callable object
    const newPost = await qf<{id: number, title: string}>({
      url: 'https://jsonplaceholder.typicode.com/posts',
      method: HttpMethod.POST,
      payload: {
        title: 'Quokka Fetch',
        body: 'Zero dependencies!',
        userId: 1,
      }
    });
    console.log('✅ POST Success:', newPost.id, newPost.title);

    // Testing callable API structure with parameters
    const getObject = {
      method: HttpMethod.GET,
      params: { page: 2, name: 'value' },
      url: 'https://jsonplaceholder.typicode.com/users/1',
      timeout: 5000
    };

    const directUser = await qf<{name: string}>(getObject);
    console.log('✅ Parameterized Object Success:', directUser.name);

    // Testing dynamic blob downloading
    const blob = await qf
      .onRequest((config: QuokkaRequestConfig) => {
        console.log('Intercepted request out:', config.url);
        return config;
      })({
        url: 'https://jsonplaceholder.typicode.com/posts/1',
        method: HttpMethod.GET,
        responseType: ResponseType.BLOB
      }) as Blob;
      
    console.log('✅ Blob Parsing Success & Chainable Hook worked, type:', blob.type, 'size:', blob.size);
    
    // Testing Timeout
    try {
      console.log('Testing timeout (should fail)...');
      await qf({
        url: 'https://jsonplaceholder.typicode.com/posts',
        method: HttpMethod.GET,
        timeout: 1
      });
    } catch (e) {
      const error = e as Error;
      console.log('✅ Timeout Success: Caught error ->', error.message);
    }

    // Testing Explicit AbortSignal
    try {
      console.log('Testing Explicit AbortSignal (should fail immediately)...');
      const abortController = new AbortController();
      abortController.abort(); // Triggers immediately

      await qf({
        url: 'https://jsonplaceholder.typicode.com/posts',
        method: HttpMethod.GET,
        signal: abortController.signal
      });
    } catch (e) {
      const error = e as Error;
      console.log('✅ Explicit Abort Success: Caught error ->', error.message);
    }
    
    console.log('\nAll tests passed successfully! 🎉');
  } catch (error) {
    console.error('❌ Test failed:', error);
  }
}

test();
